package com.example.app3;

import android.os.Bundle;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class ViewPagerAdapter extends FragmentPagerAdapter {
    private ArrayList<Mquestion> mquestions;

    public ViewPagerAdapter(FragmentManager fm,ArrayList<Mquestion> mquestionlist) {
        super(fm);
        this.mquestions = mquestionlist;
    }

    @Override
    public Fragment getItem(int position) {
        QuestionFragment df = new QuestionFragment(mquestions.get(position));
        position = position+1;
//        Bundle B = new Bundle();
//        B.putString("message","Q:"+position);
//        df.setArguments(B);
        return df;
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        position = position+1;
        return "Q("+position+")";
    }
}
