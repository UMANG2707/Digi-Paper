package com.example.app3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class Mcq_Quiz extends AppCompatActivity {

    private Toolbar T;
    private ViewPager V;
    private ViewPagerAdapter PA;
    private TabLayout TL;
    ArrayList<Mquestion> mquestions = new ArrayList<>();
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    String Subject_Name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mcq__quiz);
//        T = findViewById(R.id.toolbar);
//        setSupportActionBar(T);
        Intent i = getIntent();
        Subject_Name = i.getStringExtra("Subject_Name");
        V = findViewById(R.id.Pager);

        TL = findViewById(R.id.tabs);



        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Questions").child(Subject_Name);
    }

    @Override
    protected void onStart() {

        databaseReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mquestions.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    Mquestion q = ds.getValue(Mquestion.class);
                    mquestions.add(q);
                }
                Collections.shuffle(mquestions);
                PA = new ViewPagerAdapter(getSupportFragmentManager(),mquestions);
                V.setAdapter(PA);
                TL.setupWithViewPager(V);



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        super.onStart();
    }
}
