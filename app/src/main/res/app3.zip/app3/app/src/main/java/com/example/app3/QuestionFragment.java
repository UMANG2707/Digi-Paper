package com.example.app3;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class QuestionFragment extends Fragment {
    private TextView tv;
    private Button btn_op1,btn_op2,btn_op3,btn_op4;
    private String correctanswer;
    private Mquestion mquestion;

    public QuestionFragment()
    {

    }

    public QuestionFragment(Mquestion mquestion)
    {
        this.mquestion = mquestion;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_question, container, false);
        tv = view.findViewById(R.id.txt_display);
        btn_op1 = view.findViewById(R.id.optionA);
        btn_op2 = view.findViewById(R.id.optionB);
        btn_op3 = view.findViewById(R.id.optionC);
        btn_op4 = view.findViewById(R.id.optionD);
        tv.setText(mquestion.getQuestion());
        btn_op1.setText(mquestion.getOp1());
        btn_op2.setText(mquestion.getOp2());
        btn_op3.setText(mquestion.getOp3());
        btn_op4.setText(mquestion.getOp4());
//        tv.setText(getArguments().getString("message"));
        return view;
    }
}
